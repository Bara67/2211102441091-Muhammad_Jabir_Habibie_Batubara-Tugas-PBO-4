import greenfoot.*;

public class Banana extends Actor {
    private GreenfootSound collectSound = new GreenfootSound("collectcoin.wav");
    
    public Banana() {
        setImage("banana.png"); // Ganti "banana.png" dengan gambar objek Banana yang sesuai
    }
    
    public void act() {
        moveDown();
        checkForCollision();
    }
    
    public void moveDown() {
        setLocation(getX(), getY() + 1);
      
        if (getY() >= getWorld().getHeight() - 1) {
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
        }
    }
    
    public void checkForCollision() {
        Monkey player = (Monkey) getOneIntersectingObject(Monkey.class);
        if (player != null) {
            player.increaseScore();
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
            playCollectSound();
        }
    }

    public void playCollectSound() {
        collectSound.play();
    }
}
