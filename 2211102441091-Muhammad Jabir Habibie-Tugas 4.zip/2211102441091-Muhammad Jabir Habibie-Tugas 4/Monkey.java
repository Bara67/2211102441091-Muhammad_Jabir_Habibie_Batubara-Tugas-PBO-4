import greenfoot.*;

public class Monkey extends Actor {
    private int score = 0;

    public Monkey() {
        setImage("monyetpuyuh.png"); // Ganti "monkey.png" dengan gambar karakter Monkey yang sesuai
    }

    public void act() {
        checkKeyPress();
        checkGameOver();
        checkForCollision();
    }

    public void checkKeyPress() {
        if (Greenfoot.isKeyDown("left")) {
            move(-5);
        }
        if (Greenfoot.isKeyDown("right")) {
            move(5);
        }
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 5);
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 5);
        }
    }

    public void checkForCollision() {
        Actor banana = getOneIntersectingObject(Banana.class); // Ganti "ObjectSpecial" menjadi "Banana"
        if (banana != null) {
            increaseScore();
            getWorld().removeObject(banana);
        }
    }

    public void increaseScore() {
        score += 10;
        getWorld().showText("Score: " + score, 50, 25);
    }

    public void checkGameOver() {
        if (score >= 100) {
            getWorld().showText("Game Over You Win!", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            Greenfoot.stop();
        } else if (getWorld().getObjects(Monkey.class).isEmpty()) {
            getWorld().showText("Game Over You Lose!", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            Greenfoot.stop();
        }
    }
}
